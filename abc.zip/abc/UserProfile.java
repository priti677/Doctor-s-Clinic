package abc;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
public class UserProfile extends Login{

	public static void main(String[] args) {
		JFrame frame=new JFrame("Profile");
		JLabel l1=new JLabel("Name:");
		l1.setBounds(10, 20, 80, 30);
		JLabel l2=new JLabel();
		l2.setBounds(100, 20, 80, 30);
		JLabel l3=new JLabel("Email:");
		l3.setBounds(10, 70, 80, 30);
		JLabel l4=new JLabel();
		l4.setBounds(100, 70, 80, 30);
		JLabel l5=new JLabel("Phno:");
		l5.setBounds(10, 120, 80, 30);
		JLabel l6=new JLabel();
		l6.setBounds(100, 120, 80, 30);
		JLabel l7=new JLabel("Password:");
		l7.setBounds(10, 170, 80, 30);
		JLabel l8=new JLabel();
		l8.setBounds(100, 170, 80, 30);
		frame.add(l1);frame.add(l2);frame.add(l3);frame.add(l4);
		frame.add(l5);frame.add(l6);frame.add(l7);frame.add(l8);
		frame.setSize(350,350);
		frame.setLayout(null);
		frame.setVisible(true);
	    Connection con;
	    PreparedStatement pstm;
		ResultSet rs;
		
		try
		{
		 Class.forName("com.mysql.cj.jdbc.Driver");
         con=DriverManager.getConnection("jdbc:mysql://localhost:3306/user_record","root","anindya@1234");
         pstm=con.prepareStatement("select *from user where Email=? and Password=?" );
         pstm.setString(1,Email);
         pstm.setString(2,Pass);
         String name=null,email=null,phno=null,pass=null;
    
         rs=pstm.executeQuery();
         while(rs.next())
         {
        	 name=rs.getString(1);
        	 email=rs.getString(2);
        	 phno=rs.getString(3);
        	 pass=rs.getString(4);
         }
        	 
        	 l2.setText(name);
        	 l4.setText(email);
        	 l6.setText(phno);
        	 l8.setText(pass);
         
		}catch(Exception e1) {}
}
}