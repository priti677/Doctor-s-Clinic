package abc;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;


import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Login {
	static String Email,Pass;
	public static void main(String[] args) {
		JFrame frame=new JFrame("User Login");
		JLabel l1=new JLabel("Enter email:");
		JTextField tf1=new JTextField();
		JLabel l2=new JLabel("Enter Password:");
		JTextField tf2=new JTextField();
		JButton b1=new JButton("Login");
		l1.setBounds(10, 20, 100, 30);
		tf1.setBounds(130, 20, 140, 30);
		l2.setBounds(10, 60, 100, 30);
		tf2.setBounds(130, 60, 140, 30);
		b1.setBounds(130, 100, 80, 30);
		frame.add(l1);
		frame.add(tf1);
		frame.add(l2);
		frame.add(tf2);
		frame.add(b1);
		frame.setSize(320,200);
		frame.setLayout(null);
		frame.setVisible(true);
		b1.addActionListener(new ActionListener() { 
	        public void actionPerformed(ActionEvent e) {
	        	Email=tf1.getText();
	        	Pass=tf2.getText();
	            Connection con;
	        	PreparedStatement pstm;
	        	ResultSet rs;
	        	boolean status=false;
	        	try
	        	{
	        	Class.forName("com.mysql.cj.jdbc.Driver");
	        	con=DriverManager.getConnection("jdbc:mysql://localhost:3306/user_record","root","anindya@1234");
	        	pstm=con.prepareStatement("select *from user where EMail=? and password=?");
	        	pstm.setString(1, Email);
	        	pstm.setString(2, Pass);
	        	rs=pstm.executeQuery();
	        	status=rs.next();
	        	if(status)
	        	{
	        		UserPannel.main(new String[]{});
		    		frame.dispose(); 
	        	}
	        	else {
	        	JOptionPane.showMessageDialog(frame,"Email or Password not Matched!"); 
	        	}
	        	}catch(Exception e1) {}
	        }});
	
	}

}
