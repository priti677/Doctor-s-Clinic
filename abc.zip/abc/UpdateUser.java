package abc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class UpdateUser extends AdminPannel{

	public static void main(String[] args) {
		JFrame f= new JFrame("Update");  
        JLabel l1,l2,l3,l4,l5;  
        JTextField tf1,tf2,tf3,tf4;
        l1=new JLabel("***Update Screen***");
       l1.setBounds(150,10,150,50);
        l2=new JLabel("Enter Name:");  
        l2.setBounds(10,50, 100,30);  
        tf1=new JTextField();  
        tf1.setBounds(110,54,150,20);  
        l3=new JLabel("Enter Email:");  
        l3.setBounds(10,100,100,30);  
        tf2=new JTextField();  
        tf2.setBounds(110,104,150,20); 
        l4=new JLabel("Enter Phno:");  
        l4.setBounds(10,150,100,30);  
        tf3=new JTextField();  
        tf3.setBounds(110,154,150,20); 
        l5=new JLabel("Enter Password:");  
        l5.setBounds(10,200,100,30);  
        tf4=new JTextField();  
        tf4.setBounds(110,204,150,20); 
        JButton b1=new JButton("Update");
        b1.setBounds(110,250,120,30);
        f.add(l1);f.add(l2);f.add(tf1);f.add(l3);f.add(tf2);
        f.add(l4);f.add(tf3);f.add(l5);f.add(tf4);f.add(b1);
        f.setLayout(null);
        f.setSize(400,400);
        f.setVisible(true);
        
        Connection con;
	    PreparedStatement pstm;
		ResultSet rs;
		
		try
		{
		 Class.forName("com.mysql.cj.jdbc.Driver");
         con=DriverManager.getConnection("jdbc:mysql://localhost:3306/user_record","root","anindya@1234");
         pstm=con.prepareStatement("select *from user where Email=?" );
         pstm.setString(1,uemail);
         
         String name=null,email=null,phno=null,pass=null;
    
         rs=pstm.executeQuery();
         while(rs.next())
         {
        	 name=rs.getString(1);
        	 email=rs.getString(2);
        	 phno=rs.getString(3);
        	 pass=rs.getString(4);
          }
        	//System.out.println(name); 
        	 tf1.setText(name);
        	 tf2.setText(email);
        	 tf3.setText(phno);
        	 tf4.setText(pass);
         
		}catch(Exception e1) {}
		

	}

}
