package abc;
import javax.swing.*;
import java.awt.*;
public class ViewUser {

	public static void main(String[] args) {
		JFrame frame=new JFrame("View User");
		frame.setSize(300,300);
		frame.setLayout(null);
		frame.setVisible(true);

	}

}
