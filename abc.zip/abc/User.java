package abc;
import java.awt.event.*;
import javax.swing.*;

public class User {

	public static void main(String[] args) {
		JFrame frame=new JFrame("User Screen");
		JButton b1=new JButton("Register");
		JButton b2=new JButton("Login");
		b1.setBounds(60, 60, 120, 30);
		b2.setBounds(60, 100, 120, 30);
		frame.add(b1);
		frame.add(b2);
		frame.setSize(250,250);
		frame.setLayout(null);
		frame.setVisible(true);
		b1.addActionListener(new ActionListener() { 
	        public void actionPerformed(ActionEvent e) {
	        	Register.main(new String[]{});
	    		//frame.dispose(); 
	        }});

		b2.addActionListener(new ActionListener() { 
	        public void actionPerformed(ActionEvent e) {
	        	Login.main(new String[]{});
	    		//frame.dispose(); 
	        }});

	}

}
