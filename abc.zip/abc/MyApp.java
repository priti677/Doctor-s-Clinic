package abc;
import javax.swing.*;
import java.awt.event.*;
public class MyApp {

	public static void main(String[] args) {
		JFrame frame=new JFrame("MyApp");
		JLabel l1=new JLabel("Enter Text:");
		l1.setBounds(10, 40, 120, 30);
		JTextField tf1=new JTextField();
		tf1.setBounds(140, 40, 120, 30);
		JButton b1=new JButton("Click");
		b1.setBounds(110, 180, 80, 30);
		frame.add(l1);
		frame.add(tf1);
		frame.add(b1);
        b1.addActionListener(new ActionListener() {  
        	public void actionPerformed(ActionEvent e) {  
        		String str=tf1.getText();
        		 JOptionPane.showMessageDialog(frame,str); 	
        	}
        	});

		frame.setSize(300,500);
		frame.setLayout(null);
		frame.setVisible(true);

	}

}
