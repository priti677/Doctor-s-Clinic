package abc;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
public class Register {

	public static void main(String[] args) {
		
				JFrame f= new JFrame("Registration");  
		        JLabel l1,l2,l3,l4,l5;  
		        JTextField tf1,tf2,tf3,tf4;
		        l1=new JLabel("***Registration Screen***");
		       l1.setBounds(150,10,150,50);
		        l2=new JLabel("Enter Name:");  
		        l2.setBounds(10,50, 100,30);  
		        tf1=new JTextField();  
		        tf1.setBounds(110,54,150,20);  
		        l3=new JLabel("Enter Email:");  
		        l3.setBounds(10,100,100,30);  
		        tf2=new JTextField();  
		        tf2.setBounds(110,104,150,20); 
		        l4=new JLabel("Enter Phno:");  
		        l4.setBounds(10,150,100,30);  
		        tf3=new JTextField();  
		        tf3.setBounds(110,154,150,20); 
		        l5=new JLabel("Enter Password:");  
		        l5.setBounds(10,200,100,30);  
		        tf4=new JTextField();  
		        tf4.setBounds(110,204,150,20); 
		        JButton b1=new JButton("Register");
		        b1.setBounds(110,250,120,30);
		        f.add(l1);f.add(l2);f.add(tf1);f.add(l3);f.add(tf2);
		        f.add(l4);f.add(tf3);f.add(l5);f.add(tf4);f.add(b1);
		        f.setLayout(null);
		        f.setSize(400,400);
		        f.setVisible(true);
		        
		        b1.addActionListener(new ActionListener() { 
		        public void actionPerformed(ActionEvent e) {
		        	String Name=tf1.getText();
		        	String Email=tf2.getText();
		        	String Phno=tf3.getText();
		        	String Pass=tf4.getText();
		        	Connection con;
		        	PreparedStatement pstm;
		        	try
		        	{
		        	Class.forName("com.mysql.cj.jdbc.Driver");
		        	con=DriverManager.getConnection("jdbc:mysql://localhost:3306/user_record","root","anindya@1234");
		        	pstm=con.prepareStatement("insert into user values(?,?,?,?)");
		        	pstm.setString(1, Name);
		        	pstm.setString(2, Email);
		        	pstm.setString(3, Phno);
		        	pstm.setString(4, Pass);
		        	pstm.executeUpdate();
		        	JOptionPane.showMessageDialog(f,"You have Been Sucessfully Registered!"); 
		        	con.close();
		        	}catch(Exception e1) {}
		        }});
		        }

	}


