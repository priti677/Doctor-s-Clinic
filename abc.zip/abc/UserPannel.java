package abc;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

public class UserPannel {

	public static void main(String[] args) {
		JFrame frame=new JFrame("User Pannel");
		JButton b1=new JButton("View Profile");
		JButton b2=new JButton("Logout");
		b1.setBounds(60, 60, 120, 30);
		b2.setBounds(60, 100, 120, 30);
		frame.add(b1);
		frame.add(b2);
		frame.setSize(250,250);
		frame.setLayout(null);
		frame.setVisible(true);
		b1.addActionListener(new ActionListener() { 
	        public void actionPerformed(ActionEvent e) {
	        	UserProfile.main(new String[]{});
	    		//frame.dispose(); 
	        }});
		
		b2.addActionListener(new ActionListener() { 
	        public void actionPerformed(ActionEvent e) {
	        	Home.main(new String[] {});
	        	frame.dispose();
	        }});
		frame.setSize(400,400);
		frame.setLayout(null);
		frame.setVisible(true);


	}

}
