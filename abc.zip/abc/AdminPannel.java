package abc;
import java.awt.event.*;
import javax.swing.*;
public class AdminPannel {
	static String uemail;

	public static void main(String[] args) {
		JFrame frame=new JFrame("Admin Pannel");
		frame.setSize(300,350);
		frame.setLayout(null);
		frame.setVisible(true);
		JButton b1=new JButton("View User");
		JButton b2=new JButton("Add User");
		JButton b3=new JButton("Update User");
		JButton b4=new JButton("Delete User");
		JButton b5=new JButton("Logout");
		
		b1.setBounds(80, 60, 120, 30);
		b2.setBounds(80, 100, 120, 30);
		b3.setBounds(80, 140, 120, 30);
		b4.setBounds(80, 180, 120, 30);
		b5.setBounds(80, 220, 120, 30);
		
		frame.add(b1);
		frame.add(b2);
		frame.add(b3);
		frame.add(b4);
		frame.add(b5);
		
		b1.addActionListener(new ActionListener() { 
	        public void actionPerformed(ActionEvent e) {
	        	ViewUser.main(new String[]{});
	    		//frame.dispose(); 
	        }});
		
		b2.addActionListener(new ActionListener() { 
	        public void actionPerformed(ActionEvent e) {
	        	Register.main(new String[]{});
	    		//frame.dispose(); 
	        }});
		b3.addActionListener(new ActionListener() { 
	        public void actionPerformed(ActionEvent e) {
	        	uemail=JOptionPane.showInputDialog(frame,"Enter Email to Update"); 
	        	//if()
	        	UpdateUser.main(new String[]{});
	    		//frame.dispose(); 
	        }});
	}
	}